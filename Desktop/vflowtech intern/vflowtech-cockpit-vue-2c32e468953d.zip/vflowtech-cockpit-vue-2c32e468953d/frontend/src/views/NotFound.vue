<template>
  <p>Page not found</p>
</template>

<style>

</style>